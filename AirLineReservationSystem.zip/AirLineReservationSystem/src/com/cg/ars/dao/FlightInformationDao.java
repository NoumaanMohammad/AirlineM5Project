package com.cg.ars.dao;

import java.util.Date;
import java.util.List;

import org.springframework.web.servlet.ModelAndView;

import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface FlightInformationDao {
	public void addFlight(FlightInformation fi) throws AirLineManagementException;

	public List<FlightInformation> getflightInformationOnDestination(
			String destination);

	public List<FlightInformation> getflightInformationOnDay(
			Date day);

	public List<FlightInformation> getflightInformationOnFlightNo(
			int flightNo);

	public List<FlightInformation> getflighInformationOnAirLines(
			String airline);
}
