package com.cg.ars.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;


@Repository
public class BookingInformationDaoImpl implements BookingInformationDao {

	@PersistenceContext
	EntityManager entityManager;
	

	


	@Override
	public List<BookingInformation> getpassengerInformationOnAirLines(
			int flForPassenger) {
		List<BookingInformation> passenger;
		
		try
		{
			TypedQuery<BookingInformation> tQueryBookInfo =entityManager.createQuery("from BookingInformation booking where booking.flightno=:flForPassenger", BookingInformation.class);
			tQueryBookInfo.setParameter("flForPassenger",flForPassenger );
			passenger=tQueryBookInfo.getResultList();
			for(BookingInformation b:passenger)
			{
				System.out.println(b.getBookingId());
			}
			if(tQueryBookInfo==null)
			{
				throw new AirLineManagementException("No Flights to display");
			}
		}catch(AirLineManagementException e)
		{
			throw new AirLineManagementException("No Flights to display");
		}
		System.out.println(passenger.size());
		return passenger;
	}
	
}
