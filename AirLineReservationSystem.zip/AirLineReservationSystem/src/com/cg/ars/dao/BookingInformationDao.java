package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface BookingInformationDao {
	
	

	public List<BookingInformation> getpassengerInformationOnAirLines(
			int flForPassenger);
}
