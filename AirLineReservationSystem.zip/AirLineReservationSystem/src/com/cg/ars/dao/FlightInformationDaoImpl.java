package com.cg.ars.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;



import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;
@Repository
public class FlightInformationDaoImpl implements FlightInformationDao{
@PersistenceContext
EntityManager em;
	@Override
	public void addFlight(FlightInformation fi) throws AirLineManagementException {
		
		try {
			em.persist(fi);
			em.flush();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		}
		
	}
	@Override
	public List<FlightInformation> getflighInformationOnAirLines(
			String airline) {
		List<FlightInformation> listAirline=null;
		try
		{
			TypedQuery<FlightInformation> tQueryAirline=em.createQuery("from FlightInformation flight where flight.airline=:airline", FlightInformation.class);
			tQueryAirline.setParameter("airline", airline);
			listAirline=tQueryAirline.getResultList();
			if(tQueryAirline==null)
			{
				throw new AirLineManagementException("No Flights to display");
			}
		}catch(AirLineManagementException e)
		{
			throw new AirLineManagementException("No Flights to display");
		}
		return listAirline;
	}
	
	@Override
	public List<FlightInformation> getflightInformationOnDestination(
			String destination) {
		List<FlightInformation> listDest=new ArrayList<FlightInformation>();
		try
		{
			TypedQuery<FlightInformation> tQueryDest =em.createQuery("from FlightInformation flight where flight.deptcity=:destination", FlightInformation.class);
			tQueryDest.setParameter("destination", destination);
			listDest=tQueryDest.getResultList();
			if(tQueryDest==null)
			{
				throw new AirLineManagementException("No Flights to display");
			}
		}catch(AirLineManagementException e)
		{
			throw new AirLineManagementException("No Flights to display");
		}
		return listDest;
	}
	@Override
	public List<FlightInformation> getflightInformationOnDay(
			Date day) {
		List<FlightInformation> listDay=new ArrayList<FlightInformation>();
		try
		{
			TypedQuery<FlightInformation> tQueryDay =em.createQuery("from FlightInformation flight where flight.deptdate=:day", FlightInformation.class);
			tQueryDay.setParameter("day", day);
			listDay=tQueryDay.getResultList();
			if(tQueryDay==null)
			{
				throw new AirLineManagementException("No Flights to display");
			}
		}catch(AirLineManagementException e)
		{
			throw new AirLineManagementException("No Flights to display");
		}
		return listDay;
	}
	@Override
	public List<FlightInformation> getflightInformationOnFlightNo(
			int flightNo) {
		List<FlightInformation> listflightNo=null;
		try
		{
			TypedQuery<FlightInformation> tQueryDay =em.createQuery("from FlightInformation flight where flight.flno=:flightNo", FlightInformation.class);
			tQueryDay.setParameter("flightNo",flightNo );
			listflightNo=tQueryDay.getResultList();
			if(tQueryDay==null)
			{
				throw new AirLineManagementException("No Flights to display");
			}
		}catch(AirLineManagementException e)
		{
			throw new AirLineManagementException("No Flights to display");
		}
		return listflightNo;
	}
	
	

}






























