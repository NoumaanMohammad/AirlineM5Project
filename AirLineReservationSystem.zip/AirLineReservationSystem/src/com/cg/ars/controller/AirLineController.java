package com.cg.ars.controller;


import java.util.Date;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;
import com.cg.ars.service.BookingInformationService;
import com.cg.ars.service.FlightInformationService;
import com.cg.ars.util.StringToDate;

@Controller
public class AirLineController {
	
	@Autowired
	BookingInformationService bookingService;
	@Autowired
	FlightInformationService flightService;
	@InitBinder
	public void  initBinder(WebDataBinder binder)
	{
		binder.registerCustomEditor(Date.class, new StringToDate());
	}
	
	
	@RequestMapping(value="/home")      //homepage(common for all)
	public String goToHome() {
		return "homePage";
	}
	
	


	@RequestMapping(value="admin")
	public String adminPg(Model m)
	{
		System.out.println("admin login");
		return "loginPg";
	}
	@RequestMapping(value="adminMenu")
	public String adminmenu(Model m)
	{
		System.out.println("admin menu");
		return "menuPg";
	}
	@RequestMapping(value="updateandmanage")
	public String adminupdate(Model m){
		return "updatemenuPg";
		
	}
	@RequestMapping(value="adminview")
	public String adminView(Model m)
	{
		return "adminmenuPg";
	}
	
//update and manage 
@RequestMapping(value="addFlight")
public String addFlight(Model m)
{
	m.addAttribute("flight", new FlightInformation());
	return "addFlight";
}

@RequestMapping(value="processaddFlight")
public String processadd(@ModelAttribute("addfl") FlightInformation flInfo,BindingResult result,Model m ) throws AirLineManagementException
{
	System.out.println("gng to service");
flightService.addFlight(flInfo);
	try {
			m.addAttribute("flight",new FlightInformation());
			return "addFlight";
	}
	
	 catch (AirLineManagementException e) {
		
		e.printStackTrace();
	}
	
	
	return "addFlight";
}
@RequestMapping(value="schedule")
public String updateSchedule(Model m)
{
	
	return "schedule";
}
@RequestMapping(value="fare")
public String updateFare(Model m)
{
	return "fare";
}
@RequestMapping(value="srcanddest")	
public String updateSrcDest()
{
	return "srcanddest";
}

//view details for admin.............................................................................................
@RequestMapping(value="airlines",method=RequestMethod.GET)
public String adminViewBasedOnAirlines(Model m)
{
	System.out.println("in Airlines");
	
	return "airlineDetails";
}
@RequestMapping( value="processairlineDetails",method=RequestMethod.POST )
public String processviewDetailsAirlines(@RequestParam("airline") String airline, Model m  )
{
	
	
	try {
		List<FlightInformation> airlineList=flightService.getflighInformationOnAirLines(airline);
		m.addAttribute("flight",airlineList);
		return  "airlineDetails";
		
	} catch (AirLineManagementException e) {
		return "errorPg";
		//return "errorPg";
		//e.printStackTrace();
	}
	
	
}

@RequestMapping(value="dest",method=RequestMethod.GET)
public String adminViewBasedOnDest(Model m)
{
	
	return "destDetails";
}
@RequestMapping(value="processDestDetails",method=RequestMethod.POST)
public String processviewDetailsDest( Model m, @RequestParam("deptcity") String destination)
{
	
	try {
		List<FlightInformation> airlineList=flightService.getflightInformationOnDestination(destination);
		m.addAttribute("destination",airlineList);
		return "destDetails";
	} catch (AirLineManagementException e) {
		return "errorPg";
		//e.printStackTrace();
	}
	
}

@RequestMapping(value="day",method=RequestMethod.GET)
public String adminViewBasedOnDay(Model m)
{
	
	return "dayDetails";
}
@RequestMapping(value="processdayDetails",method=RequestMethod.POST)
public String processviewDay( Model m, @RequestParam("day")Date day)
{
	
	try {
		List<FlightInformation> airlineList=flightService.getflightInformationOnDay(day);
		m.addAttribute("day",airlineList);
		return "dayDetails";
	} catch (AirLineManagementException e) {
		return "errorPg";
		//e.printStackTrace();
	}
	
}
@RequestMapping(value="flightNo",method=RequestMethod.GET)
public String adminViewBasedOnFlighNo(Model m)
{
	
	return "flightNoDetails";
}
@RequestMapping(value="processflightDetails",method=RequestMethod.POST)
public String processviewFlightNo( Model m, @RequestParam("flno") int flightNo)
{
	
	try {
		List<FlightInformation> airlineList=flightService.getflightInformationOnFlightNo(flightNo);
		m.addAttribute("flightNo",airlineList);
		return "flightNoDetails";
	} catch (AirLineManagementException e) {
		return "errorPg";
		//e.printStackTrace();
	}
	
}

@RequestMapping(value="passengers",method=RequestMethod.GET)
public String adminViewBasedOnPassengers(Model m)
{
	
	return "passengerDetails";
}
@RequestMapping(value="processpassengerDetails",method=RequestMethod.POST)
public String processviewPassenger(Model m,int flForPassenger)
{
	try {
		List<BookingInformation> airlineList=bookingService.getpassengerInformationOnAirLines(flForPassenger);
		m.addAttribute("passenger",airlineList);
		for(BookingInformation b:airlineList)
		{
			System.out.println(b.getBookingId());
		}
		return "passengerDetails";
	} catch (AirLineManagementException e) {
		return "errorPg";
		//e.printStackTrace();
	}
}

}














































