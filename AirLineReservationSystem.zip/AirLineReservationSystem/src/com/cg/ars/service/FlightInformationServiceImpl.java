package com.cg.ars.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ars.dao.FlightInformationDao;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;
@Service
@Transactional
public class FlightInformationServiceImpl implements FlightInformationService 
{
	@Autowired
	FlightInformationDao fdao;
	public FlightInformationDao getFdao() {
		return fdao;
	}

	public void setFdao(FlightInformationDao fdao) {
		this.fdao = fdao;
	}

	//(rollbackFor=AirLineManagementException.class)
	@Override
	public void addFlight(FlightInformation fi) 	throws AirLineManagementException {
		 fdao.addFlight(fi);
	}
	
	@Override
	public List<FlightInformation> getflightInformationOnDestination(
			String destination) {
		
		return fdao.getflightInformationOnDestination(destination);
	}
	
	@Override
	public List<FlightInformation> getflightInformationOnDay(
			Date day) {
		return fdao.getflightInformationOnDay(day);
	}
	@Override
	public List<FlightInformation> getflightInformationOnFlightNo(
		int flightNo) {
	
		return fdao.getflightInformationOnFlightNo(flightNo);
	}
	@Override
	public List<FlightInformation> getflighInformationOnAirLines(
			String airline) {
		return fdao.getflighInformationOnAirLines(airline);
	}
	
	
}


