package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface BookingInformationService {

	

	public List<BookingInformation> getpassengerInformationOnAirLines(
			int flForPassenger);

}
