package com.cg.ars.exception;

public class AirLineManagementException extends RuntimeException{

	private static final long serialVersionUID = -7777846365302441037L;

	public AirLineManagementException() {
	
	}

	public AirLineManagementException(String arg0) {
		super(arg0);
	}
	

}
