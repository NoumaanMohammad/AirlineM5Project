package com.cg.ars.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="flightinformation")
/*@NamedQueries( value={ 
		@NamedQuery(name="GetFlightDetailsByAirline", query="from flightinformation airline"),
		@NamedQuery(name="GetFlightDetailsByFlightNo", query="from flightinformation flightNo"),
		@NamedQuery(name="GetFlightDetailsByDay", query="from flightinformation day"),
		@NamedQuery(name="GetFlightDetailsByDestination", query="from flightinformation destination")
		})*/
public class FlightInformation {
	@Id
	@Column(name="flightno")
	private int flno;
	
	private String airline;
	
	@Column(name="arr_city")
	private String arrcity;
	
	@Column(name="dep_city")
	private String deptcity;
	
	@Column(name="dep_date")
	private Date deptdate;
	
	@Column(name="arr_date")
	private Date arrdate;
	
	@Column(name="dep_time")
	private String depttime;
	
	@Column(name="arr_time")
	private String arrtime;
	
	@Column(name="FirstSeats")
	private int firstseats;
	
	@Column(name="BussSeats")
	private int bussseats;
	
	@Column(name="FirstSeatFare")
	private double firstseatsfare;
	
	@Column(name="BussSeatsFare")
	private double bussseatsfare;
	
	
	public int getFlno() {
		return flno;
	}
	public void setFlno(int flno) {
		this.flno = flno;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getArrcity() {
		return arrcity;
	}
	public void setArrcity(String arrcity) {
		this.arrcity = arrcity;
	}
	public String getDeptcity() {
		return deptcity;
	}
	public void setDeptcity(String deptcity) {
		this.deptcity = deptcity;
	}
	public Date getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(Date deptdate) {
		this.deptdate = deptdate;
	}
	public Date getArrdate() {
		return arrdate;
	}
	public void setArrdate(Date arrdate) {
		this.arrdate = arrdate;
	}
	public String getDepttime() {
		return depttime;
	}
	public void setDepttime(String depttime) {
		this.depttime = depttime;
	}
	public String getArrtime() {
		return arrtime;
	}
	public void setArrtime(String arrtime) {
		this.arrtime = arrtime;
	}
	public int getFirstseats() {
		return firstseats;
	}
	public void setFirstseats(int firstseats) {
		this.firstseats = firstseats;
	}
	public int getBussseats() {
		return bussseats;
	}
	public void setBussseats(int bussseats) {
		this.bussseats = bussseats;
	}
	public double getFirstseatsfare() {
		return firstseatsfare;
	}
	public void setFirstseatsfare(double firstseatsfare) {
		this.firstseatsfare = firstseatsfare;
	}
	public double getBussseatsfare() {
		return bussseatsfare;
	}
	public void setBussseatsfare(double bussseatsfare) {
		this.bussseatsfare = bussseatsfare;
	}
	@Override
	public String toString() {
		return "FlightInformation [flno=" + flno + ", airline=" + airline
				+ ", arrcity=" + arrcity + ", deptcity=" + deptcity
				+ ", deptdate=" + deptdate + ", arrdate=" + arrdate
				+ ", depttime=" + depttime + ", arrtime=" + arrtime
				+ ", firstseats=" + firstseats + ", bussseats=" + bussseats
				+ ", firstseatsfare=" + firstseatsfare + ", bussseatsfare="
				+ bussseatsfare + "]";
	}
	
}

	

